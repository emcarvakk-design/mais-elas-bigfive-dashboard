"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/lqa-profiles.mjs
var lqa_profiles_exports = {};
__export(lqa_profiles_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(lqa_profiles_exports);
var handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const siteUrl = process.env.URL || "https://reliable-strudel-dea19d.netlify.app";
    const resp = await fetch(`${siteUrl}/lqa_resultados.json`);
    if (!resp.ok) {
      throw new Error(`Falha ao carregar resultados: ${resp.status}`);
    }
    const data = await resp.json();
    const profiles = Object.entries(data).map(([id, value]) => ({
      id,
      ...value.respondente,
      classificacao: value.classificacao
    }));
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ respondentes: profiles, total: profiles.length })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message, respondentes: [], total: 0 })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
