"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/lqa-sync.mjs
var lqa_sync_exports = {};
__export(lqa_sync_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(lqa_sync_exports);
var SUPABASE_URL = "https://qhzlhomuhebknkcklagf.supabase.co";
var SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFoemxob211aGVia25rY2tsYWdmIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3OTEzMzE2MSwiZXhwIjoyMDk0NzA5MTYxfQ.748vWBPN3rRU_biV8S05GovPZFDwuS04LFuHPmgs-1I";
var SHEET_ID = "136RxxsS6wV9H9BoUCGGfxirm5_59SOZzmEhmHCloKwA";
var GID_FORM1 = "749797565";
var GID_FORM2 = "1137073244";
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
function parseCSV(csvText) {
  const lines = csvText.split("\n").filter((l) => l.trim());
  if (lines.length < 2) return [];
  const headers = parseCSVLine(lines[0]);
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    if (values.length < 3) continue;
    const row = {};
    headers.forEach((h, idx) => {
      row[h] = values[idx] ?? "";
    });
    rows.push(row);
  }
  return rows;
}
function parseCSVLine(line) {
  const result = [];
  let current = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === "," && !inQuotes) {
      result.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}
async function fetchSheet(gid) {
  const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=${gid}`;
  const res = await fetch(url, { redirect: "follow" });
  if (!res.ok) throw new Error(`Sheets HTTP ${res.status} para gid=${gid}`);
  return res.text();
}
async function supabaseGet(path) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    headers: {
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`
    }
  });
  if (!res.ok) throw new Error(`Supabase GET ${path}: ${res.status}`);
  return res.json();
}
async function supabaseUpsert(table, data) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: "POST",
    headers: {
      apikey: SUPABASE_KEY,
      Authorization: `Bearer ${SUPABASE_KEY}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates"
    },
    body: JSON.stringify(data)
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Supabase upsert ${table}: ${res.status} \u2014 ${err}`);
  }
  return res;
}
function classificarRespondente(form1Row, form2Row) {
  const r = form1Row;
  const scores = {
    P06: 0,
    // Centralizador
    P03: 0,
    // Estruturador
    P10: 0,
    // Reativo
    P28: 0,
    // Compulsivo
    P29: 0
    // Ansioso por velocidade
  };
  const q15 = getField(r, ["Q15", "Pergunta 15", 15]);
  if (q15?.includes("fazendo junto") || q15?.includes("mais r\xE1pido") || q15?.includes("fico mais tranquilo quando fa\xE7o eu mesmo")) scores.P06 += 3;
  const q16 = getField(r, ["Q16", "Pergunta 16", 16]);
  if (q16?.includes("preferia ter feito eu mesmo") || q16?.includes("padr\xE3o caiu")) scores.P06 += 3;
  const q28 = getField(r, ["Q28", "Pergunta 28", 28]);
  if (q28?.includes("Pressiono por velocidade") || q28?.includes("precisa acelerar agora")) scores.P06 += 2;
  const q32 = getField(r, ["Q32", "Pergunta 32", 32]);
  if (q32 === "Com frequ\xEAncia" || q32 === "Com frequencia" || q32 === "Sempre") scores.P06 += 2;
  const q51 = getField(r, ["Q51", "Pergunta 51", 51]);
  if (q51?.includes("Interrompo") && q51?.includes("explico")) scores.P06 += 1;
  const q18 = getField(r, ["Q18", "Pergunta 18", 18]);
  if (q18 === "Sempre" || q18 === "Com frequ\xEAncia" || q18 === "Com frequencia") scores.P03 += 2;
  const q23 = getField(r, ["Q23", "Pergunta 23", 23]);
  if (q23 === "Sempre" || q23 === "Com frequ\xEAncia" || q23 === "Com frequencia") scores.P03 += 2;
  const q41 = getField(r, ["Q41", "Pergunta 41", 41]);
  if (q41?.includes("cad\xEAncia") || q41?.includes("Isso n\xE3o acontece")) scores.P03 += 1;
  const q25 = getField(r, ["Q25", "Pergunta 25", 25]);
  if (q25?.includes("irritado") || q25?.includes("lentid\xE3o me incomoda") || q25?.includes("nomear")) scores.P29 += 3;
  if (q28?.includes("Pressiono") || q28?.includes("acelerar agora")) scores.P10 += 1;
  if (q32 === "Com frequ\xEAncia" || q32 === "Com frequencia") scores.P10 += 1;
  if (form2Row) {
    const f2q2 = getField(form2Row, ["Q2", "Pergunta 2", 2]);
    if (f2q2?.includes("Mantenho minha posi\xE7\xE3o") || f2q2?.includes("mais experi\xEAncia")) scores.P06 += 2;
    const f2q18 = getField(form2Row, ["Q18", "Pergunta 18", 18]);
    if (f2q18?.includes("suavizo") || f2q18?.includes("ningu\xE9m fique")) scores.P10 += 1;
  }
  const sorted = Object.entries(scores).sort((a, b) => b[1] - a[1]);
  const [perfilPrincipal, scorePrincipal] = sorted[0];
  const [perfilSecundario] = sorted[1];
  const perfilFinal = scorePrincipal >= 3 ? perfilPrincipal : "P06";
  const confianca = form2Row ? scorePrincipal >= 5 ? "alta" : "media" : "media";
  return {
    perfil_codigo: perfilFinal,
    perfil_secundario: perfilSecundario !== perfilFinal ? perfilSecundario : "P10",
    confianca,
    scores
  };
}
function getField(row, keys) {
  if (!row) return void 0;
  for (const key of keys) {
    if (row[key] !== void 0 && row[key] !== "") return row[key];
    if (typeof key === "number") {
      const found = Object.entries(row).find(([k]) => {
        const match = k.match(/(\d+)/);
        return match && parseInt(match[1]) === key;
      });
      if (found) return found[1];
    }
  }
  return void 0;
}
var PERFIS = {
  P06: {
    nome: "Gestor Centralizador",
    macrogrupo: "B",
    macrogrupo_nome: "B \u2014 Rela\xE7\xE3o com Poder, Controle e Autoridade",
    blanchard_quadrante: "S1",
    blanchard_recomendado: "Coaching (S2)",
    dilts_dominante: "Comportamento",
    dilts_gap: "Capacidade",
    fpc_dimensao: "Controle e Execu\xE7\xE3o",
    gap: "Sustentar a delega\xE7\xE3o sem retomar a execu\xE7\xE3o",
    forca: "Clareza de dire\xE7\xE3o e orienta\xE7\xE3o a resultado"
  },
  P03: {
    nome: "Gestor Estruturador",
    macrogrupo: "A",
    macrogrupo_nome: "A \u2014 Rela\xE7\xE3o com Estrutura e Processo",
    blanchard_quadrante: "S2",
    blanchard_recomendado: "Coaching (S2) com desenvolvimento para S3",
    dilts_dominante: "Comportamento",
    dilts_gap: "Identidade",
    fpc_dimensao: "Estrutura e Processo",
    gap: "Desenvolver flexibilidade quando o processo n\xE3o serve ao contexto",
    forca: "Clareza de processo e comunica\xE7\xE3o estruturada"
  },
  P10: {
    nome: "Gestor Reativo",
    macrogrupo: "C",
    macrogrupo_nome: "C \u2014 Rela\xE7\xE3o com Press\xE3o e Resultado",
    blanchard_quadrante: "S1",
    blanchard_recomendado: "Suporte (S3)",
    dilts_dominante: "Comportamento",
    dilts_gap: "Cren\xE7a",
    fpc_dimensao: "Reatividade Emocional",
    gap: "Criar pausa entre o est\xEDmulo e a resposta",
    forca: "Alta energia e senso de urg\xEAncia"
  },
  P28: {
    nome: "Gestor Compulsivo",
    macrogrupo: "B",
    macrogrupo_nome: "B \u2014 Rela\xE7\xE3o com Poder, Controle e Autoridade",
    blanchard_quadrante: "S1",
    blanchard_recomendado: "Coaching (S2)",
    dilts_dominante: "Identidade",
    dilts_gap: "Cren\xE7a",
    fpc_dimensao: "Controle Compulsivo",
    gap: "Distinguir controle necess\xE1rio de controle ansioso",
    forca: "Alta consist\xEAncia e previsibilidade"
  },
  P29: {
    nome: "Gestor Ansioso por Velocidade",
    macrogrupo: "C",
    macrogrupo_nome: "C \u2014 Rela\xE7\xE3o com Press\xE3o e Resultado",
    blanchard_quadrante: "S2",
    blanchard_recomendado: "Coaching (S2)",
    dilts_dominante: "Comportamento",
    dilts_gap: "Capacidade",
    fpc_dimensao: "Ansiedade por Velocidade",
    gap: "Transformar impaci\xEAncia em pergunta antes de agir",
    forca: "Alta orienta\xE7\xE3o a resultado e proatividade"
  }
};
function buildRecord(submissionId, form1Row, form2Row, classificacao) {
  const perfil = PERFIS[classificacao.perfil_codigo] || PERFIS.P06;
  const perfilSec = PERFIS[classificacao.perfil_secundario] || PERFIS.P10;
  const evidencias = [];
  const q15 = getField(form1Row, ["Q15", 15]);
  if (q15) evidencias.push(`Q15: "${q15.substring(0, 80)}"`);
  const q16 = getField(form1Row, ["Q16", 16]);
  if (q16) evidencias.push(`Q16: "${q16.substring(0, 80)}"`);
  const q25 = getField(form1Row, ["Q25", 25]);
  if (q25) evidencias.push(`Q25: "${q25.substring(0, 80)}"`);
  const q28 = getField(form1Row, ["Q28", 28]);
  if (q28) evidencias.push(`Q28: "${q28.substring(0, 80)}"`);
  const q32 = getField(form1Row, ["Q32", 32]);
  if (q32) evidencias.push(`Q32: "${q32}"`);
  const nome = form1Row["Nome completo"] || form1Row["Nome"] || form1Row["name"] || "Respondente";
  const email = form1Row["E-mail"] || form1Row["Email"] || form1Row["email"] || "";
  const timestampRaw = form1Row["Carimbo de data/hora"] || form1Row["Timestamp"] || form1Row["timestamp"] || "";
  return {
    id: submissionId,
    nome,
    email,
    timestamp: timestampRaw ? new Date(timestampRaw).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
    perfil_codigo: classificacao.perfil_codigo,
    macrogrupo: perfil.macrogrupo,
    macrogrupo_nome: perfil.macrogrupo_nome,
    perfil_nome: perfil.nome,
    confianca: classificacao.confianca,
    perfil_secundario: classificacao.perfil_secundario,
    evidencias_chave: evidencias,
    blanchard: {
      quadrante: perfil.blanchard_quadrante,
      estilo_recomendado: perfil.blanchard_recomendado,
      nivel_competencia: "moderado",
      nivel_comprometimento: "vari\xE1vel",
      justificativa: `Perfil ${classificacao.perfil_codigo} \u2014 ${perfil.nome}. Gap principal: ${perfil.gap}.`
    },
    dilts: {
      nivel_dominante: perfil.dilts_dominante,
      nivel_gap: perfil.dilts_gap,
      descricao: `Opera no n\xEDvel de ${perfil.dilts_dominante}. Gap em ${perfil.dilts_gap}.`,
      impacto_lideranca: `Padr\xE3o ${classificacao.perfil_codigo} com perfil secund\xE1rio ${classificacao.perfil_secundario}.`
    },
    meta_programas: {
      aproximacao_evitacao: "Misto",
      interno_externo: "Interno",
      opcoes_procedimentos: "Misto",
      global_detalhe: "Misto",
      proativo_reativo: "Misto",
      padrao_dominante: `Padr\xE3o ${classificacao.perfil_codigo} detectado com confian\xE7a ${classificacao.confianca}.`,
      implicacao_operacional: perfil.gap
    },
    fpc: {
      dimensao_dominante: perfil.fpc_dimensao,
      padrao_dominante: `${perfil.nome} \u2014 ${perfil.gap}`,
      risco_operacional: `Perfil secund\xE1rio ${perfilSec.nome} ativado sob press\xE3o.`,
      forca_central: perfil.forca
    },
    lqa_consolidado: {
      gap_prioritario: perfil.gap,
      forca_dominante: perfil.forca,
      risco_ativado: `${perfilSec.nome} como padr\xE3o secund\xE1rio.`,
      acao_inicial: `Semana 1: identificar 1 situa\xE7\xE3o onde o padr\xE3o ${classificacao.perfil_codigo} foi ativado e registrar o gatilho.`,
      evidencia_esperada: `Ao final da semana 1: clareza sobre o principal gatilho do padr\xE3o ${classificacao.perfil_codigo}.`,
      nota_metodologica: form2Row ? `Classificado com Form 1 e Form 2. Confian\xE7a: ${classificacao.confianca}.` : `Classificado apenas com Form 1. Form 2 pendente. Confian\xE7a: ${classificacao.confianca}. Reprocessar ap\xF3s Form 2.`
    },
    raw_form1: form1Row,
    raw_form2: form2Row || null,
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  };
}
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS_HEADERS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: "M\xE9todo n\xE3o permitido. Use POST." })
    };
  }
  try {
    const existentes = await supabaseGet("lqa_resultados?select=id,confianca");
    const existentesMap = new Map(existentes.map((r) => [r.id, r.confianca]));
    const [csv1, csv2] = await Promise.all([
      fetchSheet(GID_FORM1),
      fetchSheet(GID_FORM2)
    ]);
    const rows1 = parseCSV(csv1);
    const rows2 = parseCSV(csv2);
    const form2Map = /* @__PURE__ */ new Map();
    for (const row of rows2) {
      const cols = Object.values(row);
      const submissionId = cols[1];
      if (submissionId) form2Map.set(submissionId, row);
    }
    const novos = [];
    const atualizados = [];
    for (const row of rows1) {
      const cols = Object.values(row);
      const submissionId = cols[1];
      if (!submissionId) continue;
      const jaExiste = existentesMap.has(submissionId);
      const confiancaAtual = existentesMap.get(submissionId);
      const form2 = form2Map.get(submissionId) || null;
      if (jaExiste && confiancaAtual === "alta") continue;
      const classificacao = classificarRespondente(row, form2);
      const record = buildRecord(submissionId, row, form2, classificacao);
      await supabaseUpsert("lqa_resultados", record);
      if (jaExiste) {
        atualizados.push(record.nome);
      } else {
        novos.push(record.nome);
      }
    }
    const todos = await supabaseGet(
      "lqa_resultados?select=id,nome,email,timestamp,perfil_codigo,macrogrupo,macrogrupo_nome,perfil_nome,confianca,perfil_secundario,evidencias_chave,blanchard,dilts,meta_programas,fpc,lqa_consolidado&order=timestamp.desc"
    );
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success: true,
        novos: novos.length,
        atualizados: atualizados.length,
        nomes_novos: novos,
        nomes_atualizados: atualizados,
        total: todos.length,
        respondentes: todos
      })
    };
  } catch (error) {
    console.error("lqa-sync error:", error);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({ error: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
